#include "SistemaImobiliaria.h"
#include <vector>

void SistemaImobiliaria::cadastraImovel(Imovel* imoveis){
    this->imoveis.push_back(imoveis);
}

SistemaImobiliaria::SistemaImobiliaria(std::vector <Imovel*> imoveis){
    this -> imoveis = imoveis;
}

std::vector <Imovel*> SistemaImobiliaria::getImovel(){
    return this->imoveis;
}

void SistemaImobiliaria::removerImovel(std::string titulo)
{
    unsigned int contador; int aux = -1;
    for(contador = 0; contador < imoveis.size(); contador++)
        {
            if(titulo.compare(imoveis[contador]->getTitulo()) == 0)
            {
                aux = contador;
                break;
            }
        }
    if(aux != -1){
        imoveis.erase(imoveis.begin()+aux);
        std::cout << "Imovel removido!\n" << std::endl;
    }
    if(aux == -1)
        std::cout << "Imovel nao encontrado, repita a operacao!\n" << std::endl;

}
